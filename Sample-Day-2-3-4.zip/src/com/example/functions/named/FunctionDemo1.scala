package com.example.functions.named

object Main {

	def main(args:Array[String]) :Unit =  {
		
		greet()
		greet

		//Call anynomous function from this line
		a()
		b("Ram")
		
		var i = 100 //type inference
		var j = 100 //type inference
		println(i + j)
		println(i.+(j))
		println(i +(j))
		
		println(a)
		println(a.getClass())


		say()		
		
		def say() {
			println("Sayyy.....")
		}
		
		var yes = () => {
			println("Yes....")
		}

		say()
		yes() 

		var rs = sum(2,2)
		println(rs)

		rs = diff(2,2)
		println(rs)

		rs = add(20,20)
		println(rs)

		rs = multiply(20,20)
		println(rs)

		rs = cal(20,20)
		println(rs)

		rs = sqrt(10)
		println(rs)

	}	

	var sqrt = (arg:Int) => arg * arg
	
	var cal = (i:Int,j:Int) => i * j

	def multiply(i:Int,j:Int) :Int = i * j

	//def multiply(i:Int,j:Int) :Int = { i * j }

	/*def multiply(i:Int,j:Int) :Int = {
		i * j
	}*/

	var add  = (i:Int,j:Int) => {
		println("Calculating and returning value")
		i + j
	}

	def diff(i:Int,j:Int) :Int = {
		println("Calculating and returning value")
	 	i - j
	}

	def sum(i:Int,j:Int) :Int = {
		println("Calculating and returning value")
		return i + j
	}

	//Function expression
	//Anonymous function
	//Lambda expression
	var b = (name:String) => {
		println(name)
	};

	//Function declaration
	//Named function
	def greetMe(name:String) {
		println(name)
	}

	//Anonymous function
	var a = () => {
		println("Hello....")
	};

	
	//Function declaration
	//Named function
	def greet() :Unit = {
		println("Hello....")
	}

}





