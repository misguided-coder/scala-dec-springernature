package com.example.functions.composition

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		UC3
	}

	//Function composition or better function inversion
	def UC3: Unit ={

		val calculateGST = (amount:Double) => {
			println("GST calculated and applied")
			amount * .18
		}

		val calculateTDS = (amount:Double) => {
			println("TDS calculated and applied")
			amount * .10
		}

		val calculateDA = (amount:Double) => {
			println("DA calculated and applied")
			amount * .08
		}

		val calculateAmount = calculateGST compose  calculateTDS compose  calculateDA

		println(calculateAmount(20000.00))
	}


	//Function composition
	def UC2: Unit ={

		val calculateGST = (amount:Double) => {
			println("GST calculated and applied")
			amount * .18
		}

		val calculateTDS = (amount:Double) => {
			println("TDS calculated and applied")
			amount * .10
		}

		val calculateDA = (amount:Double) => {
			println("DA calculated and applied")
			amount * .08
		}

		//val calculateAmount = calculateGST andThen calculateTDS andThen calculateDA
		val calculateAmount = calculateGST.andThen(calculateTDS.andThen(calculateDA))

		println(calculateAmount(20000.00))
	}


	def UC1: Unit ={

		def calculateGST(amount:Double): Double = {
			println("GST calculated and applied")
			amount * .18
		}

		def calculateTDS(amount:Double): Double = {
			println("TDS calculated and applied")
			amount * .10
		}

		println(calculateGST(10000.00))
		println(calculateTDS(10000.00))
	}
}





