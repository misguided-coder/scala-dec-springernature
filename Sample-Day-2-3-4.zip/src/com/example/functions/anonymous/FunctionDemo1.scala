package com.example.functions.anonymous

object Main {

	def main(args:Array[String]) :Unit =  {
		println(sqrt(2))
	}	

	var sqrt = (arg:Int) => arg * arg
	
	var cal = (i:Int,j:Int) => i * j


	var add  = (i:Int,j:Int) => {
		println("Calculating and returning value")
		i + j
	}


	//Function expressions
	//Anonymous functions
	//Lambda expressions
	//Unnamed functions
	var b = (name:String) => {
		println(name)
	}

	//Anonymous function
	var a = () => {
		println("Hello....")
	}

}





