package com.example.functions.anonymous.exercise

//Developer A designed very generic futuristic Math API around lambda/functional programming
/*
* Author : Ritesh
* Date  : 10 Dec 2016
* Version : 1.0
*/

object MathService {

	type SimpleFn = () => Unit
	type ConsumerFn = (Int,Int) => Unit
	type ProviderFn = () => Int
	type OperatorFn = (Int,Int,Int) => Int

	//def calculate(fn:(Int,Int)=>Unit) {
	def calculate(fn:ConsumerFn) {
		println("Loading configurations!!!!")
		println("Doing internal calculations!!!!")
		fn(100,50) //callback function
		println("Calculation done!!!!")
	}

	//def calculate(i:Int,j:Int,fn:(Int,Int)=>Unit) {
	def calculate(i:Int,j:Int,fn:ConsumerFn) {
		println("Loading configurations!!!!")
		println("Doing internal calculations!!!!")
		fn(i,j) //callback function
		println("Calculation done!!!!")
	}

	def calculate(i:Int,j:Int,k:Int,fn:OperatorFn) {
		println("Loading configurations!!!!")
		println("Doing internal calculations!!!!")
		println(fn(i,j,k)) //callback function
		println("Calculation done!!!!")
	}

}





