package com.example.functions.anonymous.exercise

//Developer B using Math API desigen by Developer A
/*
* Author : Ram
* Date  : 12 Jan 2020
* Version : 1.0
*/
object UserService {

	def main(args:Array[String]) :Unit =  {


		//Behavioral Injection
		MathService.calculate((i:Int,j:Int) => println(i*j)) //inline programming
		MathService.calculate((i:Int,j:Int) => println(i/j)) //inline programming
		MathService.calculate((i:Int,j:Int) => println(i%j)) //inline programming
		MathService.calculate((i:Int,j:Int) => println(i + i + j)) //inline programming
		MathService.calculate((i:Int,j:Int) => println(i + i + j + j)) //inline programming

		MathService.calculate(10,5,(i:Int,j:Int) => println(i + j))
		MathService.calculate(40,5,(i:Int,j:Int) => println(i + j))

		MathService.calculate(1,2,3,(i:Int,j:Int,k:Int) => i + j+ k)

		EmployeeService.filter((name:String) => name.length > 5)
		println("==============================================")
		EmployeeService.filter((name:String) => name.length > 7)
		println("==============================================")
		EmployeeService.filter((name:String) => name.startsWith("R"))
		println("==============================================")
		EmployeeService.filter((name:String) => name.contains("t"))
		println("==============================================")
		EmployeeService.filter((name:String) => name.contains("t") && name.length > 7)

	}
	
}





