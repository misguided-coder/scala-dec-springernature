package com.example.functions.anonymous.exercise

//Developer A designed very generic futuristic API around lambda/functional programming which is
// based on internal iterations practice frequently used in big data world
/*
* Author : Ritesh
* Date  : 10 Dec 2016
* Version : 1.0
*/

object EmployeeService {

	var inMemoryDB = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
		"Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
		"Rose Gulabi", "Laden Humble", "Dawood Raja")

	def filter(fn:(String)=>Boolean) {
		println("Loading configurations!!!!")
		println("Loading data from DB/BigDB!!")
		//200 LOC
		for(name <- inMemoryDB){
			if(fn(name)){
				println(name.toUpperCase)
			}
		}
		println("Data Analysis Finished!!!!")
	}

}





