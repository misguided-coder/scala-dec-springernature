package com.example.functions.curry

object Exercise {

	def main(args:Array[String]) :Unit = {

		//Violation of DRY principle
		displayWeather("Delhi")(10)
		displayWeather("Delhi")(15)
		displayWeather("Delhi")(20)

		//No Violation of DRY principle
		//Function composition
		var displayDelhiWeather = displayWeather("Delhi")_
		var displayPuneWeather = displayWeather("Pune")_

		displayDelhiWeather(3)
		displayDelhiWeather(7)
		displayDelhiWeather(9)

		displayPuneWeather(10)
		displayPuneWeather(20)

	}

	def displayWeather(city:String)(day:Int): Unit = {
		println(s"Weather of city $city on day: $day is ${(Math.random()*50).toInt} degree")
	}

}





