package com.example.functions.partial

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		//UC5
		//UC6
		UC7
	}

	//Practical usecase plus using together andThen for chaining standard functions also
	def UC7: Unit ={

		val isEven:PartialFunction[Int,String] = {
			case value: Int if value % 2 == 0  => s"$value is EVEN Number"
		}

		val isOdd:PartialFunction[Int,String] = {
			case value: Int if value % 2 == 1  => s"$value is ODD Number"
		}

		def show(value:String): String ={
			s"$value and a WHOLE Number"
		}

		var numbers =  1 to 20

		val whichNumber = isEven orElse isOdd andThen show

		for(number <- numbers) {
			println(whichNumber(number))
		}

	}


	//Practical usecase
	def UC6: Unit ={

		val isEven:PartialFunction[Int,String] = {
			case value: Int if value % 2 == 0  => s"$value is EVEN Number"
		}

		val isOdd:PartialFunction[Int,String] = {
			case value: Int if value % 2 == 1  => s"$value is ODD Number"
		}

		var numbers =  1 to 20

		/*for(number <- numbers){
			if(isEven.isDefinedAt(number))
					println(isEven(number))
		}

		for(number <- numbers){
			if(isOdd.isDefinedAt(number))
				println(isOdd(number))
		}*/

		val whichNumber = isEven orElse isOdd

		for(number <- numbers) {
				println(whichNumber(number))
		}

	}


	//Creating Partial function using case expressions and combining them using orElse
	def UC5: Unit ={

		val uptoHundredToDouble:PartialFunction[Int,Double] = {
			case value: Int if value > 0 && value <= 100 => value.toDouble
		}

		val uptoThousandToDouble:PartialFunction[Int,Double] = {
			case value: Int if value > 100 && value <= 1000 => value.toDouble
		}

		val numbersToDouble = uptoHundredToDouble orElse(uptoThousandToDouble)
		println(numbersToDouble(50))
		println(numbersToDouble(150))
		println(numbersToDouble(500))
		println(numbersToDouble(800))
		println(numbersToDouble(900))

	}


	//Creating Partial function using case expressions
	def UC4: Unit ={

		val sqrt:PartialFunction[Int,Int] = {
				case value: Int if value > 5 => value * value
		}

		//Test first before calling
		if(sqrt.isDefinedAt(2)) {
			println(sqrt(2))
			println(sqrt.apply(2))
		}


		//Test first before calling
		if(sqrt.isDefinedAt(4))
			println(sqrt(4))

		//Test first before calling
		if(sqrt.isDefinedAt(6)) {
			println(sqrt(6))
			println(sqrt.apply(6))
		}

		sqrt.apply(10)
		sqrt(10)
		sqrt(20)
		sqrt(30)
		sqrt(40)
		sqrt(1)
		sqrt(2)
		sqrt(3)
		sqrt(4)
	}


	//Creating Partial function using PartialFunction trait
	def UC3: Unit ={

		val sqrt = new PartialFunction[Int,Int] {
			//This is called only if given condition is satisfied by isDefinedAt
			override def apply(value:Int): Int = {
				println("Inside apply()!!!!!!")
				value * value
			}

			//This is used to decide on which input values are acceptable
			override def isDefinedAt(value: Int): Boolean = {
				println("Inside isDefinedAt()!!!!!!")
				value > 5
			}
		}

		//Test first before calling
		if(sqrt.isDefinedAt(2))
			println(sqrt(2))

		//Test first before calling
		if(sqrt.isDefinedAt(4))
			println(sqrt(4))

		//Test first before calling
		if(sqrt.isDefinedAt(6))
			println(sqrt(6))

	}


	//Creating Function0 instance by using it directly
	def UC2: Unit ={

		val sqrt = new Function0[Int] {
			override def apply(): Int = {
				println("Inside apply()!!!!!!")
				10 * 10
			}
		}
		println(sqrt())
		println(sqrt.apply())
	}

	//Creating Function0 instance by using literal lambda expression
	def UC1: Unit ={
			val sqrt = () => 2 * 2
			println(sqrt.isInstanceOf[Function0[Int]])
			println(sqrt())
			println(sqrt.apply())
	}
}





