package com.example.functions.paf

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		//UC5
		//UC6
		//UC7
		//UC8
		UC9
	}

	//Converting standard method into curried and using it as PAF function
	def UC9: Unit = {
		def show(name: String, age: Int, phone: String) {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}

		//Transformed into small small many nested functions
		var rs = (show _).curried

		//rs("Ram")(32)("9810000000")

		var paf = rs("Ram")(_:Int)(_:String)
		paf(21,"90810101010")
	}


	//Converting standard function into curried and using it as PAF function
	def UC8: Unit = {
		val show = (name: String, age: Int, phone: String) => {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}

		//Transformed into small small many nested functions
		var rs = show.curried

		rs("Ram")(32)("9810000000")

		var paf = rs("Ram")(_:Int)(_:String)
		paf(21,"90810101010")
	}

	//Converting standard function into PAF function
	def UC7: Unit = {
		val show = (name: String, age: Int, phone: String) => {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}

		//var rs = show("Ram",_,_)
		//var rs = show(_,24,_)
		var rs = show(_: String, 24, _: String)
		//rs("Ram","98100000000")
		var rs1 = rs("Ram",_)
		rs1("9810000000")
	}


	//Converting standard function into PAF function
	def UC6: Unit ={
		val show = (name:String,age:Int,phone:String) => {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}

		//apply is a functional design pattern
		//apply is a function invocation pattern
		//var rs = show.apply(_,_,_) //returning remaining function
		var rs = show(_,_,_) //returning remaining function
		rs("Ram",21,"98100000000")
	}


	//Converting standard function into PAF function
	def UC5: Unit ={
		val show = (name:String,age:Int,phone:String) => {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}

		var rs = show.apply("Ram",_,_) //returning remaining function
		var rs1 = rs.apply(12,_)
		rs1("9810000")
	}

	//Converting standard function into PAF function
	def UC4: Unit ={
		val show = (name:String,age:Int,phone:String) => {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}

		//show("Ram",21,"9810101010") //used as a function
		//show.apply("Ram",21,"9810101010") //used as an object
		//var rs = show.apply("Ram",21,_) //used as an object
		//rs("9810000000")
	}

	//Calling PAF by applying few arguments
	def UC3: Unit ={
		def show(name:String)(age:Int)(phone:String): Unit = {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}
		var rs = show("Rohan")(_:Int)(_:String)
		rs(21,"981000000")
	}

	//Calling PAF by applying few arguments
	def UC2: Unit ={
		def show(name:String)(age:Int)(phone:String): Unit = {
			println(s"Name : $name and Age : $age and Phone : $phone")
		}
		var rs = show("Rohan")(21)(_)
		rs("981000000")
	}


	//Calling PAF by applying no arguments
	//Empty Applied Function
	def UC1: Unit ={
		def show(name:String)(age:Int): Unit = {
			println(s"Name : $name and Age : $age")
		}
		var rs = show _
		println(rs)
	  var rs1 = rs("Ram")
		rs1(21)
		rs("Ram")(34)
	}
}





