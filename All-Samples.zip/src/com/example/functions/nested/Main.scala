package com.example.functions.nested

object Main {

	def main(args:Array[String]) :Unit = {

		//helloA()
		//helloB()
		helloC()
	}

	var helloC =  () => {
		println("Hello All")

		var hi = () => {
			println("Hi All")

			var bye = () => {
				println("Bye All")
			}

			bye()
		}

		hi()
	}


	def helloB() = {
		println("Hello All")

		var hi = () => {
			println("Hi All")

			var bye = () => {
				println("Bye All")
			}

			bye()
		}

		hi()
	}


	def helloA() = {
		println("Hello All")

		hi()

		def hi() = {
			println("Hi All")

			bye()

			def bye() = {
				println("Bye All")
			}

			bye()

		}

		hi()

	}

}





