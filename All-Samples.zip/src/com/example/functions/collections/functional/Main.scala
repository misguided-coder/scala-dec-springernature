package com.example.functions.collections.functional

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		UC5
	}

	//Functional Combinators
	def UC5: Unit = {
		var list = (1 to 50).toList
		list.drop(30).take(10).reverse.distinct.map(_*10).foreach(println)

		println(list drop 30 take 10 reverse)  //DSL
	}

	//Functional Combinators
	def UC4: Unit = {

		val isEven:PartialFunction[Int,String] = {
			case value: Int if value % 2 == 0  => s"$value is EVEN Number"
		}

		val isOdd:PartialFunction[Int,String] = {
			case value: Int if value % 2 == 1  => s"$value is ODD Number"
		}

		def show(value:String): String ={
			s"$value and a WHOLE Number"
		}

		var numbers =  1 to 20

		val whichNumber = isEven orElse isOdd andThen show

		for(number <- numbers) {
			if(isEven.isDefinedAt(number))
				println(isEven(number))
			if(isOdd.isDefinedAt(number))
				println(isOdd(number))

			println(whichNumber(number))
		}

		var list = List(1,2,3,4,5,6,7,8,9,10)

		//println(list.map(isEven))
		println(list.collect(isEven))
		println(list.collect(isOdd))
		println(list.collect(whichNumber))

		println(list.collect({case value: Int if value % 5 == 0  => s"Value : $value" }))
		println(list.collect({case value: Int if value % 3 == 0  => s"Value : $value" }))
	}

	//Functional Combinators
	def UC3: Unit = {
		var list = List(1,2,3,4,5,6,7,8,9,10)
		var list1 = list.map(value => value * 2)
		println(list1)
		def triple(arg:Int): Int ={
			arg * 3
		}
		list1 = list.map(triple)
		println(list1)


		//This combinator has side effects
		list1.foreach(value => println(s"Value : ${value + 100}"))

		println(list.filter(value => value % 2 == 0))
		println(list.filter(value => value % 2 != 0))

		println(List(1,2,3,4,5).zip(List(6,7,8,9,10)))
		println(List(1,2,3,4,5).zip(List("Ram","Rohan","Ritesh","Mohan","Raj")))

		println(List(1,2,3,4,5,6,7,8,9,10).partition(value => value % 5 == 0))
		println(List(1,2,3,4,5,6,7,8,9,10).partition(value => value % 2 == 0))

		println(List(1,2,3,4,5,6,7,8,9,10).find(value => value % 3 == 0))
		println(List(1,2,3,4,5,6,7,8,9,10).find(value => value % 5 == 0))
		println(List(1,2,3,4,5,6,7,8,9,10).find(value => value > 8))
		println(List(1,2,3,4,5,6,7,8,9,10).find(value => value > 8))

		println(List(1,2,3,4,5,6,7,8,9,10).drop(5))
		println(List(1,2,3,4,5,6,7,8,9,10).take(5))

		println("=====================================")
		println(List(1,2,3,4,5,6,7,8,9,10).dropWhile(value => value % 2 != 0))
		println(List(1,2,3,4,5,6,7,8,9,10).dropWhile(_ % 2 != 0))

		println("=====================================")
		println(List(1,2,3,4,5,6,7,8,9,10).foldLeft(0)((accumulator,value) => accumulator + value))
		println(List(1,2,3,4,5,6,7,8,9,10).foldRight(0)((accumulator,value) => accumulator + value))

		println(List(1,2,3,4,5,6,7,8,9,10).foldLeft(0)(_ + _))

		println(List(List(1,2,3),List(1,2,3),List(1,2,3)).flatten)
		println(List(List(1,2,3),List(1,2,3),List(1,2,3)).map(value => value.map(_ * 10)))
		println(List(List(1,2,3),List(1,2,3),List(1,2,3)).map(value => value.map(_ * 10)).flatten)

		println(List(List(1,2,3),List(1,2,3),List(1,2,3)).flatMap(value => value.map(_ * 10)))


		def calculateTotalSalaries(list:List[Int],fn: Int => Int): List[Int] = {
			list.foldLeft(List[Int]())((acc,value) => {
					acc.::(fn(value))
			})
		}

		var salaries = List(1200,34500,90200,6000)

		var resultList = calculateTotalSalaries(salaries,salary => salary + 5000)
		println(resultList)
	}


	def UC2: Unit = {
		var data: Option[String] = Some("Ritesh")
		//var data: Option[String] = Some("Rohan")
		//var data: Option[String] = None

		println(data)

		data match {
			case None => println("No value found")
			case Some("Rohan") => println("Data found in option")
			case Some(a) => println(s"Any Data found in option $a")
		}

	}

	def UC1: Unit = {
		//var data = Tuple4("Ram",23,981000000,"ram@yahoo.com")
		var data = ("Ram",23,981000000,"ram@yahoo.com")

		println(data)
		println(data._1)
		println(data._2)
		println(data._3)
		println(data._4)

		data match {
			case ("Ram",23,981000000,"ram@yahoo.com") => println("Tuple match by data")
			case (a,b,c,d) => println("Any Tuple will match here")
		}

		var data1 = "Ram" -> 23
		println(data1._1)
		println(data1._2)

	}

}





