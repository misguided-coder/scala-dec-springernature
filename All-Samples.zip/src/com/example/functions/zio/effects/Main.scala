package com.example.functions.zio.effects

import zio.{Task, UIO, ZIO}
import zio._

import scala.concurrent.duration.Duration
import scala.io.StdIn


object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		UC2
	}

	//Wrap this functionalities which has side effects with external system
	def UC2: Unit ={

		def readFromKeyborad() :Task[String] = {
			ZIO.effect(StdIn.readLine())
		}

		def writeToConsole(input:String) :Task[Unit] = {
			ZIO.effect(println(input))
		}

		//IO Affects/IO Monads is used to workflows for later execution
		//Combining many side effects together
		//Chaining all side effects sequentially
		var combinedEffects = for {
			_ <- writeToConsole("Tell me your name?")
			rs1 <- ZIO.succeed(200)
			rs2 <- ZIO.succeed(10).map(_ * 2)
			data <- readFromKeyborad
			_ <- writeToConsole(s"Oh You are Mr/Miss $data $rs1 $rs2")
		} yield ()

		var runtime = Runtime.default
		runtime.unsafeRunSync(combinedEffects.fold(failure => println(failure.getMessage),success => println(success)))
	}

	//Wrap this functionalities which has side effects with external system
	def UC1: Unit ={

		var zioEffect1 = ZIO(println(("Hello, I am a side effect thing")))
		var zioEffect2 =  ZIO.effect(println(("Hello, I am a side effect thing")))
		var zioEffect3 =  ZIO.succeed(2000)
		var zioEffect4 =  ZIO.fail("I am a side effect result of external system")
		var zioEffect5 =  ZIO.effectTotal("I am a side effect which will never fail")
		var zioEffect6 =  ZIO.fromOption(Some("I am a side effect string kept in option"))
	}

}





