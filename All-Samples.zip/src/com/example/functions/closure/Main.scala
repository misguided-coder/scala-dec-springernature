package com.example.functions.closure

object Main {

	def main(args:Array[String]) :Unit = {
		UC1
	}

	def UC1: Unit ={

			def generate = {
				var initial = 5000
				println("Preparing for generating values!!!!")
				() => {
					println(s"Generated Value is ${Math.random() * initial}")
				}
			}

			generate
			println("Done!!!")
			var rs = generate
			println("Doing some work here!!!")
			println("Doing some work here!!!")
			println("Doing some work here!!!")
			println("Doing some work here!!!")
			println("Doing some work here!!!")
			rs()
	}
}





