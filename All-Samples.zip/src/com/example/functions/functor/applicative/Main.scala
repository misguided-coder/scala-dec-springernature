package com.example.functions.functor.applicative

object Main {

	def main(args:Array[String]) :Unit = {
		UC1
	}

	def UC1: Unit = {

		//Container is a Applicative Functor
		//It should have pure and apply function extra on top of Functor map
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}

			def pure(things:A) : Container[A] = Container(things)

			def apply[B](fnBag:Container[A => B]): Container[B] = {
				fnBag.map((fn) => fn(things))
			}
		}

		var thingsInsideBag = Container(100)

		val fn1 = (x:Int) => x / 2
		val fn2 = (x:Int) => (y:Int) => x + y

		var processedBag1 = thingsInsideBag.map(fn1)
		println(processedBag1)

		var processedBag2 = thingsInsideBag.map(fn2)
		println(processedBag2)

		var processedBag3 = thingsInsideBag.apply(thingsInsideBag.map(fn2))
		println(processedBag3)

	}

}





