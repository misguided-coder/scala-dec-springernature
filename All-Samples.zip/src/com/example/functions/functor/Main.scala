package com.example.functions.functor

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		UC5
	}

	//Functor benefits
	def UC5: Unit = {
		var salary:Option[Double] = Some(50000.00)
		//Business Requirement
		// Increase the salary by 20%
		// Then Add DA by 10%
		// Then Deduct TDS by 30%

		//Without Functor map
		var result = if(salary.isDefined) {
			Some(((salary.get + (salary.get * .15)) + (salary.get * .05)) - (salary.get * .30))
		} else
			None

		println(result)

		//With Functor map
		result = salary.map((value) => ((value + (value * .15)) + (value * .05)) - (value * .30))
		println(result)

		//Do the same with associative rules
		/*result = salary.map(value => value + (value * .15))
			 				.map(value => value + (value * .15))
							.map(value => value - (value * .30))
		*/

		result = salary.map(_ * 1.1).map(_ * 1.15).map(_ * 1.30)
		println(result)

	}
		//Functor Associativity Rule
	def UC4: Unit = {

		//Container is a Functor
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
		}

		case class Almonds(breed:String,quantity:Double) //KG
		case class Rice(breed:String,quantity:Double) //KG
		case class Peanuts(breed:String,quantity:Double) //KG

		var almondsBag:Container[Almonds] = Container(Almonds("Indian Almonds",10))

		val doubleAlmonds = (things:Almonds) => Almonds(things.breed,things.quantity * 2)
		val roastAlmonds = (things:Almonds) => Almonds(things.breed + " roasted",things.quantity)
		val saltAlmonds = (things:Almonds) => Almonds(things.breed + " salted",things.quantity)
		val deepFryAlmonds = (things:Almonds) => Almonds(things.breed + " deep fried",things.quantity)

		val doubleAlmondsBag = almondsBag.map(doubleAlmonds)
		val roastedAlmondsBag = almondsBag.map(roastAlmonds)
		val saltedAlmondsBag = almondsBag.map(saltAlmonds)
		val deepFriedAlmondsBag = almondsBag.map(deepFryAlmonds)

		println(doubleAlmondsBag)
		println(roastedAlmondsBag)
		println(saltedAlmondsBag)
		println(deepFriedAlmondsBag)

		//Define identity rule here
		//This rule will prove that what map does only what is says
		//This rule will prove that what map is a pure function
		//This rule will make sure that map function does not do any extra functionality
		//on the data contained inside it, only passed-in expert logic will do processing
		def identity[A](things:A): A = things

		//Apply and check identity rule on map
		//Map has to return back same Functor bag when called with identity rule
		if(almondsBag.map(identity) == almondsBag) {
			println("Identity rule is passed")
		}

		println("===============================================")
		println(almondsBag.map(doubleAlmonds).map(roastAlmonds).map(saltAlmonds).map(deepFryAlmonds))


		val bagA = almondsBag.map(doubleAlmonds).map(roastAlmonds).map(saltAlmonds).map(deepFryAlmonds)
		val bagB = almondsBag.map(things => deepFryAlmonds(saltAlmonds(roastAlmonds(doubleAlmonds(things)))))
		val bagC = almondsBag.map(things => (doubleAlmonds andThen roastAlmonds andThen saltAlmonds andThen deepFryAlmonds)(things))
		val bagD = almondsBag.map(things => (deepFryAlmonds compose  saltAlmonds compose  roastAlmonds compose  doubleAlmonds)(things))

		if(bagA == bagB && bagA == bagC && bagA == bagD) {
			println(bagA)
			println(bagB)
			println(bagC)
			println(bagD)
			println("Associativity rule is passed")
		} else{
			println("Associativity rule is failed")
		}
	}


	//Functor Identity Rule
	def UC3: Unit = {

		//Container is a Functor
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
		}

		case class Almonds(breed:String,quantity:Double) //KG
		case class Rice(breed:String,quantity:Double) //KG
		case class Peanuts(breed:String,quantity:Double) //KG

		var almondsBag:Container[Almonds] = Container(Almonds("Indian Almonds",10))

		val doubleAlmonds = (things:Almonds) => Almonds(things.breed,things.quantity * 2)
		val roastAlmonds = (things:Almonds) => Almonds(things.breed + " roasted",things.quantity)
		val saltAlmonds = (things:Almonds) => Almonds(things.breed + " salted",things.quantity)
		val deepFryAlmonds = (things:Almonds) => Almonds(things.breed + " deep fried",things.quantity)

		val doubleAlmondsBag = almondsBag.map(doubleAlmonds)
		val roastedAlmondsBag = almondsBag.map(roastAlmonds)
		val saltedAlmondsBag = almondsBag.map(saltAlmonds)
		val deepFriedAlmondsBag = almondsBag.map(deepFryAlmonds)

		println(doubleAlmondsBag)
		println(roastedAlmondsBag)
		println(saltedAlmondsBag)
		println(deepFriedAlmondsBag)

		//Define identity rule here
		//This rule will prove that what map does only what is says
		//This rule will prove that what map is a pure function
		//This rule will make sure that map function does not do any extra functionality
		//on the data contained inside it, only passed-in expert logic will do processing
		def identity[A](things:A): A = things

		//Apply and check identity rule on map
		//Map has to return back same Functor bag when called with identity rule
		if(almondsBag.map(identity) == almondsBag) {
				println("Identity rule is passed")
		}
	}


	def UC2: Unit = {

		//Container is a Functor
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
		}

		case class Almonds(breed:String,quantity:Double) //KG
		case class Rice(breed:String,quantity:Double) //KG
		case class Peanuts(breed:String,quantity:Double) //KG

		var almondsBag:Container[Almonds] = Container(Almonds("Indian",10))

		val doubleAlmonds = (things:Almonds) => Almonds(things.breed,things.quantity * 2)
		val roastAlmonds = (things:Almonds) => Almonds(things.breed + " roasted",things.quantity)
		val saltAlmonds = (things:Almonds) => Almonds(things.breed + " salted",things.quantity)
		val deepFryAlmonds = (things:Almonds) => Almonds(things.breed + " deep fried",things.quantity)

		val doubleAlmondsBag = almondsBag.map(doubleAlmonds)
		val roastedAlmondsBag = almondsBag.map(roastAlmonds)
		val saltedAlmondsBag = almondsBag.map(saltAlmonds)
		val deepFriedAlmondsBag = almondsBag.map(deepFryAlmonds)

		println(doubleAlmondsBag)
		println(roastedAlmondsBag)
		println(saltedAlmondsBag)
		println(deepFriedAlmondsBag)

	}


	/*
	 * 1) Container is the the functor
	 * 2) map is the function responsible for unwrapping and wrapping things but no business logic
	 * 3) expert guys are needed by Functor to do actual processing on the things inside bag
	 * 4) Type A here is the things which needs to be processed and kept inside the bag
	 */
	def UC1: Unit = {

		//Container is a Functor
		case class Container[A](things:A) {
			// I will unwrap the bag, get things out of it and after processing, will
			// again wrap things in the bag and will return things with bag
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
			//It is required by the bag to wrap things inside a bag and returning the bag
			//def apply[A](things:A): Container[A] = new Container(things)
		}

		//var thingsInsideBag:Container[Int] = new Container(100)
		//var thingsInsideBag:Container[Int] = Container.apply(100)
		var thingsInsideBag:Container[Int] = Container(100)

		//This guy is expert in making things half
		val halfThings = (things:Int) => things /2
		//This guy is expert in making things double
		val doubleThings = (things:Int) => things * 2
		//This guy is expert in making things triple
		val tripleThings = (things:Int) => things * 3

		val halfThingsInsideBag = thingsInsideBag.map((things)=> halfThings(things))
		//val halfThingsInsideBag = thingsInsideBag.map(halfThings)
		val doubleThingsInsideBag = thingsInsideBag.map(doubleThings)
		val tripleThingsInsideBag = thingsInsideBag.map(tripleThings)

		println(halfThingsInsideBag)
		println(doubleThingsInsideBag)
		println(tripleThingsInsideBag)

	}

}





