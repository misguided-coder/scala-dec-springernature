package com.example.functions.arguments

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		UC3
	}

	def UC3: Unit = {

		//Variable number of Arguments
		def sum(title:String,args: Int*) {
			var result = 0
			for(value <- args){
				result = result + value
			}
			println(s"$title : $result")
		}

		sum("Sum")
		sum("Sum",2)
		sum("Sum",2, 7)
		sum("Sum",2, 2, 9)
		sum("Sum",2, 2, 9, 5, 7, 12, 21, 3, 45)
	}


	def UC2: Unit = {

		//Arguments with default values i.e. options arguments
		def show(name: String, age: Int = 20, email: String, phone: String = "98000000000") = {
			println(s"Name : $name, Age : $age, Email : $email and Phone : $phone")
		}

		show("Ram", 21, "ram@gamil.com")
		show("Ram", 21, "ram@gamil.com","981111111111")
		show(email="ram@gamil.com",name="Ram",age=21)
		show(name="Ram",email="ram@gamil.com")

	}

	def UC1: Unit = {

			//Arguments with default values
			def show(name:String,age:Int,email:String,phone:String) = {
				println(s"Name : $name, Age : $age and Phone : $phone")
			}

			show("Ram",21,"ram@gamil.com","9810000000") //arguments passed by position
		  show(email="ram@gamil.com",name="Ram",age=21,phone="9810000000") //arguments passed by names
			show(age=21,phone="9810000000",email="ram@gamil.com",name="Ram") //arguments passed by names
			show(phone="9810000000",age=21,name="Ram",email="ram@gamil.com") //arguments passed by names

	}
}





