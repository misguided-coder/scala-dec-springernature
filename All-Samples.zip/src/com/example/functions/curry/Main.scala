package com.example.functions.curry

object Main {

	def main(args:Array[String]) :Unit = {

		//display("Ram",24)

		//showA("Rohan")(20)

		//showB("Rohan")(20)

		//showC("Rohan")(20)

		//Partially Applied Function created and returned
		var rs = details("Mohit")_
		rs(12)

		//Partially Applied Function created and returned
		rs = showDetails("Mohan")
		rs(12)

		//showAllDetails("Jaggu")(25)("MP","Nagpur")("981010100")

		//On Demand invocation
		var moreDetails = showAllDetails("Jaggu")(25)
		//50 LOC
		var more = moreDetails("Delhi","New Delhi")
		//100 LOC
		more("9810000000000")
	}

	//Curried function
	var showAllDetails = (name:String) => (age:Int) => (state:String,city:String) => (phone:String) =>{
		println(s"$name $age $state $city $phone")
	}

	//Curried function
	var showDetails = (name:String) => (age:Int) => {
		println(s"Name : $name and Age : $age")
	}

	//Curried function
	def details(name:String)(age:Int) {
		println(s"Name : $name and Age : $age")
	}

	//Syntax 3
	//function declaration curried way with all arguments saperated
	var showC = (name:String) => (age:Int) => {
		println(s"Name : $name and Age : $age")
	}

	//Syntax 2
	//function declaration curried way with all arguments saperated
	def showB(name:String) = (age:Int) => {
		println(s"Name : $name and Age : $age")
	}

	//Syntax 1
	//function declaration curried way with all arguments saperated
	def showA(name:String)(age:Int): Unit = {
		println(s"Name : $name and Age : $age")
	}

	//Simple function declaration with all arguments together
	def display(name:String,age:Int): Unit = {
		println(s"Name : $name and Age : $age")
	}

}





