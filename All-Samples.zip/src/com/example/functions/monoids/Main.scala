package com.example.functions.monoids

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		UC4
	}

	def UC4: Unit ={

		trait Monoid[T] {
			def empty : T
			def combine(a:T,b:T) : T
		}

		case class Money(rupees:Double,paisa:Double)

		implicit val moneyMonoid:Monoid[Money] = new Monoid[Money] {
			override def empty: Money = Money(0.0,0.0)
			override def combine(moneyA: Money, moneyB: Money): Money = {
				Money.apply(moneyA.rupees + moneyB.rupees,moneyA.paisa+moneyB.paisa)
			}
		}

		def calculateTotalSalaries(list:List[Money])(implicit monoid:Monoid[Money]): Money ={
			list.fold(monoid.empty)((arg1,arg2) => monoid.combine(arg1,arg2))
		}

		var employeeSalaries = List(Money(14000.00,50.00),Money(14000.00,50.00),Money(14000.00,50.00),Money(14000.00,50.00),Money(14000.00,50.00))

		println(s"Total salary paid per month to all employees is ${calculateTotalSalaries(employeeSalaries)}")
	}

	def UC3: Unit ={

		trait Monoid[T] {
			def empty : T
			def combine(a:T,b:T) : T
		}

		implicit val intAdditionMonoid:Monoid[Int] = new Monoid[Int] {
			override def empty: Int = 0
			override def combine(a: Int, b: Int): Int = a + b
		}

		def combineAll(list:List[Int])(implicit monoid:Monoid[Int]): Int ={
			list.fold(monoid.empty)((arg1,arg2) => monoid.combine(arg1,arg2))
		}

		var rs = combineAll(List(12,34,56,32,12,34,32,45,67))
		println(rs)
	}


	def UC2: Unit ={

		trait Monoid[T] {
			def empty : T
			def combine(a:T,b:T) : T
		}

		val intAdditionMonoid:Monoid[Int] = new Monoid[Int] {
			override def empty: Int = 0
			override def combine(a: Int, b: Int): Int = a + b
		}

		def combineAll(list:List[Int])(monoid:Monoid[Int]): Int ={
			list.fold(monoid.empty)((arg1,arg2) => monoid.combine(arg1,arg2))
		}

		var rs = combineAll(List(12,34,56,32,12,34,32,45,67))(intAdditionMonoid)
		println(rs)
	}


	def UC1: Unit ={

		//Monoid Data structure
		//Type Class
		trait Monoid[T] {
			//Identity element or Identity Rule
			def empty : T //Suggested names id,zero,identity

			//Binary Operation
			def combine(a:T,b:T) : T //Suggested names add,op
		}

		val intAdditionMonoid:Monoid[Int] = new Monoid[Int] {
			override def empty: Int = 0
			override def combine(a: Int, b: Int): Int = a + b
		}

		val intMultiplyMonoid:Monoid[Int] = new Monoid[Int] {
			override def empty: Int = 1
			override def combine(a: Int, b: Int): Int = a * b
		}

		val doubleMultiplyMonoid:Monoid[Double] = new Monoid[Double] {
			override def empty: Double = 1.0
			override def combine(a: Double, b: Double): Double = a * b
		}

		val stringAdditionMonoid:Monoid[String] = new Monoid[String] {
			override def empty: String = ""
			override def combine(a: String, b: String): String = a + b
		}

		val listMonoid:Monoid[List[Int]] = new Monoid[List[Int]] {
			override def empty: List[Int] = List()
			override def combine(a: List[Int], b: List[Int]): List[Int] = a.:::(b)
		}

		val methodMonoid:Monoid[Int => Int] = new Monoid[Int => Int] {
			override def empty: Int => Int = (a:Int) => {a}
			override def combine(a: Int => Int, b: Int => Int): Int => Int = a andThen b
		}

		println(intAdditionMonoid.empty)
		println(intAdditionMonoid.combine(10,10))

		println(intMultiplyMonoid.empty)
		println(intMultiplyMonoid.combine(10,10))

		println(doubleMultiplyMonoid.combine(10.0,10.0))

		println(stringAdditionMonoid.combine("Hello","Ji"))

		println(listMonoid.combine(List(1,2,3),List(4,5,6)))
	}
}





