package com.example.functions.accounts

object Bank {

  implicit class Account(var amount: Double) {

    def deposit(): Unit = {
      println(s"Rs./- $amount deposited into account!!!!")
    }

    def withdraw(): Unit = {
      println(s"Rs./- $amount withdrawn into account!!!!")
    }


  }

}