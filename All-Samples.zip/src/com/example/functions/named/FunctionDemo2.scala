package com.example.functions.named

object FunctionDemo2 {

	def main(args:Array[String]) :Unit = {

		greetMe("Raj")

		println(sqrt(10).getClass)

		var i = 10000 //type inference
		var salary: Int = 2000 //explicit type declaration
		println(i.getClass)
		println(salary.getClass)

		//generate()
		generate

		//println(generateUnique())
		println(generateUnique1)
		println(generateUnique2)

		var array = Array(12, 34, 56, 45, 67, 323, 23, 23, 2323, 2323)
		println(array(5)) //UAP -- Unified Access Protocol
		println(greetMe("Rohan")) //UAP -- Unified Access Protocol
	}


	def generateUnique1 =  (Math.random() * 500).toInt //UAP -- Unified Access Protocol
	var generateUnique2 =  (Math.random() * 500).toInt //UAP -- Unified Access Protocol

	//def generateUnique() =  (Math.random() * 500).toInt

	//def generateUnique() = { (Math.random() * 500).toInt }

	/*def generateUnique() = {
		(Math.random() * 500).toInt
	}*/

	//def generate() = {
	def generate = {
	println(Math.random())
	}

	//def sqrt(i:Int):Int = {
	def sqrt(i:Int) = {
		i * i
	}

	//Function declaration
	//Named function
	//def greetMe(name:String) {
	//def greetMe(name:String):Unit = {
	def greetMe(name:String) = {
		println(name)
	}

}





