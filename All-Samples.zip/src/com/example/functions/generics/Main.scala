package com.example.functions.generics

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		UC2
		UC3
	}

	def UC3: Unit = {

		class Animal[T](details: T) {

			def eat(arg: T): Unit = {

			}

			def drink[V](arg1: T, arg2: V): Unit = {

			}

			def sleep(arg: T): Unit = {

			}

		}

		var animal = new Animal[String]("It is about animals")
		animal.eat("Dog")
		animal.drink[Int]("Dog", 10)
		animal.sleep("Dog")
	}


	def UC2: Unit = {

		//T is a placeholder for actual data type
		//Template functions
		def display[T,V](value1:T,value2:V,value3:T,value4:Int) = {
			println(value1)
			println(value2)
			println(value3)
			println(value4)
		}

		display("Life is cool",12000,200,50)
		display[String,Double]("Life is cool",12000.00,"Ram",50)

	}

	def UC1: Unit = {

			def display(value:String) = {
				println(value)
			}

			display("Life is cool")
	}
}





