package com.example.functions.implicits

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		UC3

	}

	def UC3: Unit = {
		import com.example.functions.accounts.Bank._

		var amount:Double = 10000.00
		println(amount.toInt)
		// Scala will look for deposit function in Double class first
		// If not found there, then will see if there is a "implicit" function which exist with the same name
		// and corresponding class take Double argument

		amount.deposit
		amount.withdraw

		50000.deposit()
		50000.withdraw()

		//120.to(150).foreach(println)

	}

	def UC2: Unit = {
		/*var account:Account = new Account(2000.00)
		account.deposit
		account.withdraw
		*/

		var amount:Double = 10000.00
		println(amount.toInt)
		//amount.deposit //will not compile
	}

	def UC1: Unit = {
		var amount:Double = 10000.00
		println(amount)
		println(amount.toInt)
		println(amount.toString)
	}
}





