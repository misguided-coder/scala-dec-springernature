package com.example.functions.call_by_name

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		UC4
	}

	//Call By Name
	def UC4: Unit = {

		def doWork(value: => Int) = {
			println(s"Work done 10 % and Current value is ${value}")
			println(s"Work done 20 % and Current value is ${value}")
			println(s"Work done 60 % and Current value is ${value}")
			println(s"Work done 80 % and Current value is ${value}")
			println(s"Work done 100 % and Current value is ${value}")
		}

		var counter = 500

		doWork({ counter += 1; counter })
	}

	//Call By Name
	def UC3: Unit = {

		def doWork(value: => Int) = {
			println(s"Work done 10 % and Current value is ${value}")
			println(s"Work done 20 % and Current value is ${value}")
			println(s"Work done 60 % and Current value is ${value}")
			println(s"Work done 80 % and Current value is ${value}")
			println(s"Work done 100 % and Current value is ${value}")
		}

		var counter = 500

		def generateValue() = {
			println(s"Generating value")
			counter = counter + 1
			counter
		}

		doWork(generateValue)
	}

	//Call By Value
	def UC2: Unit = {

		def doWork(value:Int) = {
			println(s"Work done 10 % and Current value is ${value}")
			println(s"Work done 20 % and Current value is ${value}")
			println(s"Work done 60 % and Current value is ${value}")
			println(s"Work done 80 % and Current value is ${value}")
			println(s"Work done 100 % and Current value is ${value}")
		}

		def generateValue() = {
			println(s"Generating value")
			120
		}

		//doWork(generateValue())
		doWork(generateValue)
	}

	//Call By Value
	def UC1: Unit = {

			def doWork(value:Int) = {
				println(s"Work done 10 % and Current value is ${value}")
				println(s"Work done 20 % and Current value is ${value}")
				println(s"Work done 60 % and Current value is ${value}")
				println(s"Work done 80 % and Current value is ${value}")
				println(s"Work done 100 % and Current value is ${value}")
			}

			doWork(5)
	}
}





