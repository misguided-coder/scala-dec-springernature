package com.example.functions.recursive

import scala.annotation.tailrec

object Main {

	def main(args:Array[String]) :Unit = {
		calculate(1000,0)
		//calc(5000)
	}

	//Recursive (Head)
	def calc(value:Int): Int ={
		println("Calculating value....")
		if(value <= 0){
			println(s"Result : $value")
			0
		} else  {
			var arrayOfStackTrace = Thread.currentThread().getStackTrace
			arrayOfStackTrace.foreach(println)
			value + calc(value-1)
		}
	}

	//Tail Recursive
	@tailrec
	def calculate(value:Int,result:Int): Unit ={
		println("Calculating value....")
		if(value == 0){
			println(s"Result : $result")
		} else if(value <= 99999999) {
			var arrayOfStackTrace = Thread.currentThread().getStackTrace
			arrayOfStackTrace.foreach(println)
			calculate(value-1,result+value)
		}
	}

}





