package com.example.functions.monad

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		UC5

	}

	//Monad examples
	def UC5: Unit = {
		println(List(List(10,20,30),List(10,20,30),List(10,20,30)).flatMap(value => value.::(2000)))
	}

	//Associativity  Rule
	def UC4: Unit = {

		// Functor with unit,map and flatten or flatMap is a Monad
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
			def flatMap[B](fn:A => Container[B]): Container[B] = {
				fn(things)
			}

			def flatten = things
		}

		case class Almonds(breed:String,quantity:Double) //KG

		var almondsBag:Container[Almonds] = Container(Almonds("Indian Almonds",10))

		//Business logic experts but extra over smart logic
		val doubleAlmonds = (things:Almonds) => Container(Almonds(things.breed,things.quantity * 2))
		val tripleAlmonds = (things:Almonds) => Container(Almonds(things.breed,things.quantity * 3))

		//Left Identity Rule
		//var rulePassed = Container(Almonds("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))
		//var rulePassed = Container.apply(Almonds("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))
		var rulePassed = Container.apply(Almonds.apply("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))

		if(rulePassed)
			println("Left Identity Rule passed!!")
		else
			println("Left Identity Rule failed!!")

		//Right Identity Rule
		rulePassed = Container(Almonds("Indian Almonds",10)).flatMap(Container.apply) == Container(Almonds("Indian Almonds",10))
		if(rulePassed)
			println("Right Identity Rule passed!!")
		else
			println("Right Identity Rule failed!!")

		//Associativity  Rule
		var bagA = Container(Almonds("Indian Almonds",10)).flatMap(doubleAlmonds).flatMap(tripleAlmonds)
		var bagB = Container(Almonds("Indian Almonds",10)).flatMap(things => doubleAlmonds(things).flatMap(tripleAlmonds))
		if(bagA == bagB)
			println("Associativity  Rule passed!!")
		else
			println("Associativity  Rule failed!!")


	}


	//Right Identity Rule
	def UC3: Unit = {

		// Functor with unit,map and flatten or flatMap is a Monad
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
			def flatMap[B](fn:A => Container[B]): Container[B] = {
				fn(things)
			}

			def flatten = things
		}

		case class Almonds(breed:String,quantity:Double) //KG

		var almondsBag:Container[Almonds] = Container(Almonds("Indian Almonds",10))

		//Business logic experts but extra over smart logic
		val tripleAlmonds = (things:Almonds) => Container(Almonds(things.breed,things.quantity * 3))

		//Left Identity Rule
		//var rulePassed = Container(Almonds("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))
		//var rulePassed = Container.apply(Almonds("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))
		var rulePassed = Container.apply(Almonds.apply("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))

		if(rulePassed)
			println("Left Identity Rule passed!!")
		else
			println("Left Identity Rule failed!!")

		//Right Identity Rule
		rulePassed = Container(Almonds("Indian Almonds",10)).flatMap(Container.apply) == Container(Almonds("Indian Almonds",10))
		if(rulePassed)
			println("Right Identity Rule passed!!")
		else
			println("Right Identity Rule failed!!")

	}

	//Left Identity Rule
	def UC2: Unit = {

		// Functor with unit,map and flatten or flatMap is a Monad
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
			def flatMap[B](fn:A => Container[B]): Container[B] = {
				fn(things)
			}

			def flatten = things
		}

		case class Almonds(breed:String,quantity:Double) //KG

		var almondsBag:Container[Almonds] = Container(Almonds("Indian Almonds",10))

		//Business logic experts but extra over smart logic
		val tripleAlmonds = (things:Almonds) => Container(Almonds(things.breed,things.quantity * 3))

		//Left Identity Rule
		//val rulePassed = Container(Almonds("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))
		//val rulePassed = Container.apply(Almonds("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))
		val rulePassed = Container.apply(Almonds.apply("Indian Almonds",10)).flatMap(tripleAlmonds) == tripleAlmonds(Almonds("Indian Almonds",10))

		if(rulePassed)
			println("Left Identity Rule passed!!")
		else
			println("Left Identity Rule failed!!")

	}

	def UC1: Unit = {

		// Functor with unit,map and flatten or flatMap is a Monad
		case class Container[A](things:A) {
			def map[B](fn:A => B): Container[B] = {
				Container(fn(things))
			}
			def flatMap[B](fn:A => Container[B]): Container[B] = {
				fn(things)
			}

			def flatten = things
		}

		case class Almonds(breed:String,quantity:Double) //KG

		var almondsBag:Container[Almonds] = Container(Almonds("Indian Almonds",10))

		//Business logic experts
		val doubleAlmonds = (things:Almonds) => Almonds(things.breed,things.quantity * 2)

		//Business logic experts but extra over smart logic
		val tripleAlmonds = (things:Almonds) => Container(Almonds(things.breed,things.quantity * 3))

		val roastAlmonds = (things:Almonds) => Almonds(things.breed + " roasted",things.quantity)
		val saltAlmonds = (things:Almonds) => Almonds(things.breed + " salted",things.quantity)
		val deepFryAlmonds = (things:Almonds) => Almonds(things.breed + " deep fried",things.quantity)

		def identity[A](things:A): A = things

		if(almondsBag.map(identity) == almondsBag) {
			println("Identity rule is passed")
		}

		println("===============================================")
		println(almondsBag.map(doubleAlmonds).map(roastAlmonds).map(saltAlmonds).map(deepFryAlmonds))

		val bagA = almondsBag.map(doubleAlmonds).map(roastAlmonds).map(saltAlmonds).map(deepFryAlmonds)
		val bagB = almondsBag.map(things => deepFryAlmonds(saltAlmonds(roastAlmonds(doubleAlmonds(things)))))

		if(bagA == bagB) {
			println("Associativity rule is passed")
		} else{
			println("Associativity rule is failed")
		}

		println("===============================================")
		println(almondsBag.map(doubleAlmonds))
		println(almondsBag.map(tripleAlmonds))

		//var bag = almondsBag.map(tripleAlmonds).flatten
		var bag = almondsBag.flatMap(tripleAlmonds)

		println(bag.things.breed)
		println(bag.things.quantity)
	}
}





