package com.example.functions.errors

import scala.util.{Failure, Success, Try}

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		//UC3
		//UC4
		UC5
	}

	//Handle errors without exceptions using Either/Left/Right
	def UC5: Unit = {

		case class Pizza(name:String,qty:Int)
		case class Vegetables(qty:Int) //KG

		case class FailureReason(message:String) //KG

		object PizzaService {

			val pizzaValue = 150

			def purchasePizza(money: Int): Either[FailureReason,Pizza] = {
				for {
					veggies <- buyVeggies(money)
					pizza <- bakePizza(veggies)
				} yield pizza
			}

			def bakePizza(veggies: Vegetables): Either[FailureReason,Pizza] = {
					if (Math.random() < .40)
						Left(FailureReason(s"Baking machine is not working"))
					else
						Right(Pizza("Farm House", 2))
			}

			def buyVeggies(money: Int): Either[FailureReason,Vegetables] = {
					if (money < pizzaValue)
						Left(FailureReason(s"Not enough money for purchaging veggies, Needed  $pizzaValue"))
					else
						Right(Vegetables(10)) //KG
			}

		}

		println(PizzaService.purchasePizza(200))
	}



	//Handle errors without exceptions using Try/Success/Failure
	def UC4: Unit = {

		case class Pizza(name:String,qty:Int)
		case class Vegetables(qty:Int) //KG

		object PizzaService {

			val pizzaValue = 150

			def purchasePizza(money: Int): Try[Pizza] = {
				for {
					veggies <- buyVeggies(money)
					pizza <- bakePizza(veggies)
				} yield pizza
			}

			def bakePizza(veggies: Vegetables): Try[Pizza] = {
				Try {
					if (Math.random() < .40)
						throw new Exception(s"Baking machine is not working")
					else
						Pizza("Farm House", 2)
				}
			}

			def buyVeggies(money: Int): Try[Vegetables] = {
				Try {
					if (money < pizzaValue)
						throw new Exception(s"Not enough money for purchaging veggies, Needed  $pizzaValue")
					else
						Vegetables(10) //KG
				}
			}
		}
		println(PizzaService.purchasePizza(200))
	}

	//Handle errors without exceptions using Try/Success/Failure
	def UC3: Unit = {

		case class Pizza(name:String,qty:Int)
		case class Vegetables(qty:Int) //KG

		object PizzaService {

			val pizzaValue = 150

			def purchasePizza(money:Int): Try[Pizza] = {
				for {
					veggies <- buyVeggies(money)
					pizza <- bakePizza(veggies)
				} yield pizza
			}

			def bakePizza(veggies:Vegetables): Try[Pizza] = {
				if(Math.random() < .40)
					Failure(new Exception(s"Baking machine is not working"))
				else
					Success(Pizza("Farm House",2))
			}

			def buyVeggies(money:Int): Try[Vegetables] ={
				if(money < pizzaValue)
					Failure(new Exception(s"Not enough money for purchaging veggies, Needed  $pizzaValue"))
				else
					Success(Vegetables(10)) //KG
			}
		}

		println(PizzaService.purchasePizza(200))
	}


	//Handle errors without exceptions using Option/Some/None
	def UC2: Unit = {

		case class Pizza(name:String,qty:Int)
		case class Vegetables(qty:Int) //KG

		object PizzaService {

			val pizzaValue = 150

			def purchasePizza(money:Int): Option[Pizza] = {
				for {
					veggies <- buyVeggies(money)
					pizza <- bakePizza(veggies)
				} yield pizza
			}

			def bakePizza(veggies:Vegetables): Option[Pizza] = {
				if(Math.random() < .40)
					None
				else
					Some(Pizza("Farm House",2))
			}

			def buyVeggies(money:Int): Option[Vegetables] ={
				if(money < pizzaValue)
					None
				else
					Some(Vegetables(10)) //KG
			}
		}

		println(PizzaService.purchasePizza(200))
	}

	//Clear Violation of FP principles
	//Function signatures are not reveling the complete truth about the function return values
	//Functions have side effects while FP languages like pure functions which do not have any side effect
	//There Functions are not ready for monadiac compositions
	//There Functions are not ready for chaining coz chain will break any time
	def UC1: Unit = {

		case class Pizza(name:String,qty:Int)
		case class Vegetables(qty:Int) //KG

		object PizzaService {

			val pizzaValue = 150

			def purchasePizza(money:Int): Pizza = {
					bakePizza(buyVeggies(money))
			}

			def bakePizza(veggies:Vegetables): Pizza = {
				if(Math.random() < .40)
					throw new Exception(s"Baking machine is not working")
				else
					Pizza("Farm House",2)
			}

			def buyVeggies(money:Int): Vegetables ={
					if(money < pizzaValue)
						throw  new Exception(s"Not enough money for purchaging veggies, Needed  $pizzaValue")
					else
						Vegetables(10) //KG
			}
		}

		try {
			println(PizzaService.purchasePizza(200))
		} catch {
			case ex:Exception => println(ex.getMessage)
		}

		}
}





