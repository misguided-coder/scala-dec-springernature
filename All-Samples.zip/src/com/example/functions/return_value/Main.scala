package com.example.functions.return_value

object Main {

	type SimpleFn =  () => Unit

	def main(args:Array[String]) :Unit = {

		//var rs = helloA()
		//println(rs)
		//rs()

		//var rs = helloB()
		//println(rs)
		//rs()

		/*var rs = helloC()
		println(rs)
		rs()*/

		/*var rs = helloD()
		println(rs)
		rs()*/

		/*var rs = helloE()
		println(rs)
		rs()*/

		/*var rs = helloF()
		println(rs)
		rs()*/

		/*var rs = helloG()
		println(rs)
		rs()*/

		/*var rs = helloH()
		println(rs)
		rs()*/

		/*var rs = helloI()
		println(rs)
		rs()*/

		var rs = doWork((i:Int,j:Int) => i/j)
		println(rs)
		println(rs(100,10))

	}

	var doWork = (fn:(Int,Int)=>Int) => {
		println("Start Working")
		println(fn(1,1))
		println("Work done")
		fn
	}


	var helloI = () => {

		println("Hello All")

		() => {
			println("Hi All")
		}
	}

	def helloH() = {

		println("Hello All")

		() => {
			println("Hi All")
		}
	}

	def helloG():SimpleFn = {

		println("Hello All")

		() => {
			println("Hi All")
		}
	}


	def helloF():SimpleFn = {

		println("Hello All")

		return () => {
			println("Hi All")
		}
	}

	def helloE() = {

		println("Hello All")

		var hi = () => {
			println("Hi All")
		}

		hi
	}

	def helloD(): SimpleFn =  {

		println("Hello All")

		var hi = () => {
			println("Hi All")
		}

		hi
	}

	def helloC(): SimpleFn =  {

		println("Hello All")

		var hi = () => {
			println("Hi All")
		}

		return hi
	}


	//def helloB(): () => Unit =  {
		def helloB(): SimpleFn =  {

			println("Hello All")

			def hi() = {
				println("Hi All")
			}

			return hi
		}



	def helloA(): () => Unit = {
		println("Hello All")

		def hi() = {
			println("Hi All")
		}

		return hi
	}

}





