package com.example.functions.return_value

object Exercise {

	def main(args:Array[String]) :Unit = {
		UC1
		//UC2
	}

	//Way of calling on same line but on demand
	def UC2: Unit ={
		//grow()()()(20)()()
		growMe()()()(10)()()
	}

	//Way of calling in multiple parts
	def UC1: Unit ={
		val grown = grow()
		var young = grown()
		var strong = young()
		var stronger = strong(25)
		var killer = stronger()
		killer()

	}

	//Curried Function
	var growMe = () => () => () => (age:Int) => () => () => {
		println(s"I am now super man and kill anyone")
	}

	var grow = () => {
		println("I am just an infant now")

		() => {
			println("I am little grown")

			() => {
				println("I am now young")

				(age:Int) => {

					println(s"I am now strong and $age years old")

					() => {
						println(s"I am now very strong plus age is ${age} and can fight")

						() => {
							println(s"I am now super man plus age is ${age} and kill anyone")
						}

					}
				}
			}

		}
	}

}





