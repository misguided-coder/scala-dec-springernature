package com.example.functions.pure

import cats.effect.IO

object Main {

	def main(args:Array[String]) :Unit = {
		//UC1
		//UC2
		UC3
	}

	// Representing  effectful expression by IO Monad for lazy evaluation
	// Representing  effectful expression to execute when need
	// Representing  effectful function's complete data type like input,effect,result
	def UC3: Unit = {

		def doWork(arg1:Unit,arg2:Unit) : Unit = ()

		//Eager Evaluation
		var expression = IO(println("Doing some work")) //Effect-ful expression
		//var expression = println("Doing some work") //Effect-ful expression

		//Referential Transperency of the following expression not passed
		doWork(expression.unsafeRunSync,expression.unsafeRunSync)

		//Referential Transperency of the following expression not passed
		doWork(println("Doing some work"),println("Doing some work"))

		//Lazy Evaluation
		expression.unsafeRunSync

	}


	def UC2: Unit = {

		var amount = 1000
		var result1 = amount + amount
		//Referential Transperency of the following expression passed
		println(result1)
		var result2 = 1000 + 1000

		//Referential Transperency of the following expression passed
		println(result2)

		def doWork(arg1:Unit,arg2:Unit) : Unit = ()

		//Eager Evaluation
		var expression = println("Doing some work") //Effect-ful expression

		//Referential Transperency of the following expression not passed
		doWork(expression,expression)

		//Referential Transperency of the following expression not passed
		doWork(println("Doing some work"),println("Doing some work"))
	}

	def UC1: Unit ={

			//Pure function
			def sum(arg1:Int,arg2:Int) : Int = {
					arg1 + arg2
			}


			//Impure function
			def diff(arg1:Int,arg2:Int) : Int = {
				println("Calculation difference!!!!")
				//Call to DB
				arg1 - arg2
			}

		//Impure function
		def multiply(arg1:Int,arg2:Int) : Unit = {
			var rs = arg1 * arg2
			println(s"Result : ${rs}!!")
		}

		//Pure function
		def product(arg1:Int,arg2:Int) : Int = {
			arg1 * arg2
		}

		//Pure function with side effects = Impure
		def display() : Unit = {
			println(s"Result : ${product(10,10)}!!")
		}
	}
}





