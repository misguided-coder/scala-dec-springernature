object ImplicitDemo {
	
	def main(args:Array[String]) :Unit =  {

		//implicit var data1:String = "Good Evening All"
		//implicit var data2:String = "Good Night All"
	
		greet("Good Morning All")	
	
		//Developer B
		//Dependency Injection
		greet
	}
		
	//Developer A
	def greet(implicit message:String) :Unit =  {
		println(message)	
	}

}