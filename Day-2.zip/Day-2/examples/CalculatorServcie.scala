object CalculatorServcie {

	def main(args:Array[String]) :Unit =  {
		
		var sum = (i:Int,j:Int) => println(i+j) 
		var diff = (i:Int,j:Int) => println(i-j) 

		calculate(sum) 
		calculate(diff) 

		//Behavioral Injection
		calculate((i:Int,j:Int) => println(i*j)) //inline programming
		calculate((i:Int,j:Int) => println(i/j)) //inline programming
		calculate((i:Int,j:Int) => println(i%j)) //inline programming
		calculate((i:Int,j:Int) => println(i + i + j)) //inline programming
		calculate((i:Int,j:Int) => println(i + i + j + j)) //inline programming
	}
	
	def calculate(arg:(Int,Int)=>Unit) {
		println("Loading configurations!!!!")
		println("Doing internal calculations!!!!")
		arg(100,50) //callback function
		println("Calculation done!!!!")
	}
}





