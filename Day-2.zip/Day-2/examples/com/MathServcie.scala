package com

//Developer A designed Math API around functional programming
/*
* Author : Ritesh
* Date  : 10 Dec 2016
* Version : 1.0
*/

object MathServcie {
	
	def calculate(arg:(Int,Int)=>Unit) {
		println("Loading configurations!!!!")
		println("Doing internal calculations!!!!")
		arg(100,50) //callback function
		println("Calculation done!!!!")
	}
}





