object Main extends App {
	
	UC1()
			
	def UC1() {
		
		var i = 10
		
		i match {
			case 10 =>
				println("Small Value")	
			case 50 =>
				println("Medium Value")	
			case 100 =>
				println("Large Value")	
			case default =>
				println("Unknown Value")	
		}
		
	}

}