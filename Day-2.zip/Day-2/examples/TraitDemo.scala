class Account {
	def open() {
		println("Account opened")
	}
}

trait Closable {
	def close
}

trait Transferable {
	def transferFee {
		println("Account Transfer fee is Rs/- 10000")
	}

	def transfer {
	}
}

trait Logger {
	def fine(message:String) {
		println(s"FINE ==========> : ${message}")
	}
}


trait TimeLogger {
	def fine(message:String) {
		println(s"FINE : T${new java.util.Date()} ==========> : ${message}")
	}
}

class SavingsAccount extends Account with Closable with Transferable with TimeLogger with Logger {

	override def fine(message:String) {
		super.fine(message)
	}

	def close {
		fine("SavingsAccount  is closed")
		//println("SavingsAccount  is closed")
	}

	override def transfer {
		println("Account is Transfered")
	}

}

class CurrrentAccount extends Account with Closable with Logger {

	def close {
		fine("CurrentAccount is closed")
		println("CurrentAccount is closed")
	}
}

object Main {

	def main(args:Array[String]) :Unit =  {

		var savingsAccount  = new SavingsAccount 
		savingsAccount.open
		savingsAccount.close
		savingsAccount.transferFee
		savingsAccount.transfer
	
		var currrentAccount1  = new CurrrentAccount 
		currrentAccount1.open
		currrentAccount1.close
		currrentAccount1.fine("Current Account is in active status")


		var currrentAccount2  = new CurrrentAccount with Transferable
		currrentAccount2.open
		currrentAccount2.close
		currrentAccount2.transferFee
		currrentAccount2.transfer
		
		println()
	}	
}