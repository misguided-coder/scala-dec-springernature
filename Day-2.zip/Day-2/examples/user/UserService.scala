package user

import com._

//Developer B using Math API desigen by Developer A 
/*
* Author : Ram
* Date  : 12 Jan 2020
* Version : 1.0
*/
object UserService {

	def main(args:Array[String]) :Unit =  {
		
		//Behavioral Injection
		MathServcie.calculate((i:Int,j:Int) => println(i*j)) //inline programming
		MathServcie.calculate((i:Int,j:Int) => println(i/j)) //inline programming
		MathServcie.calculate((i:Int,j:Int) => println(i%j)) //inline programming
		MathServcie.calculate((i:Int,j:Int) => println(i + i + j)) //inline programming
		MathServcie.calculate((i:Int,j:Int) => println(i + i + j + j)) //inline programming
	}
	
}





