println("Hello to Scalable language!!")
var i:Int = 0
while(i<10) {
	println(i)
	i= i + 1
}