object Program1 {

	def main(args:Array[String]) :Unit =  {

		println("Hello to Scalable language!!")
		println("Hello to Scalable language!!")
	}

}