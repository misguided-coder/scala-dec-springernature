class Account {
	def open() {
		println("Account opened")
	}
}

trait Closable {
	def close
}

trait Transferable {
	def transferFee {
		println("Account Transfer fee is Rs/- 10000")
	}

	def transfer
}

class SavingsAccount extends Account with Closable with Transferable {

	def close {
		println("Account is closed")
	}

	def transfer {
		println("Account is Transfered")
	}

}

object Main {

	def main(args:Array[String]) :Unit =  {
		println()
	}	
}