class Car(val vin:Int,model:String,var speed:Int) {

	println("Entering constructor........")
	
	def this() {
		this(100,"BMW X5",100);
	}

	def this(vin:Int) {
		this(vin,"BMW X5",100);
	}

	def speedUp () {
		this.speed = this.speed + 10
		println(this.model+" is speedin up....")
	}

	def speedDown () {
		println(this.model+" is slowing down....")
	}

	println("Exiting constructor........")
}

object Main {

	def main(args:Array[String]) :Unit =  {
		println(new Car(100,"BMW X6",200))
		println(new Car(100))
		println(new Car())
		println(new Car)

		var car:Car = new Car(100,"BMW X6",200)
		println(car.vin)
		println(car.model)
		car.speedUp()
		car.speedDown()
	}	
}