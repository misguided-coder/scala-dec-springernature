case class Car(vin:Int,val model:String,speed:Int)

object Main {

	def main(args:Array[String]) :Unit =  {
		var car1 = new Car(1,"Audi A5",200)
		//var car2 = new Car(2,"Audi A5",200)
		var car2 = new Car(1,"Audi A5",200)

		var car3 = car1.copy() //copy and update while copying
		var car4 = car1.copy(speed=500) //copy and update while copying

		var car5 = Car.apply(100,"Audi Q4",800)

		//Object identity
		println(car1.eq(car2))

		//Object equality
		println(car1 == car2)
		println(car1.equals(car2))
		
		println(car1.hashCode())
		println(car2.hashCode())
				
							
		println(car1.toString())
		println(car1)
	}	
}