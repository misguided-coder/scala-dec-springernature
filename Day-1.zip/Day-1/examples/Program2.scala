def hello()  {
	println("Hello to Scalable language!!")
}

hello()

