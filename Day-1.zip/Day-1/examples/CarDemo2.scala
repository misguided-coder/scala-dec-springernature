class Car(vin:Int,val model:String,var speed:Int) {

	println("Entering constructor........")
	
	def this() {
		this(100,"BMW X5",100);
	}

	def this(vin:Int) {
		this(vin,"BMW X5",100);
	}

	def speedUp () {
		this.speed = this.speed + 10
		println(this.model+" is speedin up....")
	}

	def speedDown () {
		this.speed = this.speed - 10
		println(this.model+" is slowing down and running at the speed of "+this.speed+ " miles per hr")
	}


	def info () {
		println(s"VIN : ${this.vin}")
		println(s"Model : ${this.model}")
		println(s"Speed : ${this.speed}")
	}

	println("Exiting constructor........")
}


class LuxuryCar extends Car 
class SedanCar() extends Car(1,"Audi Q7",100)
class SuvCar(speed:Int,sport:Boolean = true) extends Car(1,"Audi Q7",speed) {

	override def speedUp () {
		//this.speed = this.speed + 50
		println(this.model+" SUV is speeding up....")
	}

	override def info () {
		super.info
		println(s"Sport : ${this.sport}")
	}

}

object Main {

	def main(args:Array[String]) :Unit =  {
		println(new LuxuryCar)
		println(new SedanCar())
		println(new SuvCar(240))
	
		var suvCar = new SuvCar(240)
		suvCar.speedDown
		suvCar.speedUp
		suvCar.info
	}	
}